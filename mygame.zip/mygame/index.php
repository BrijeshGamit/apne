<!DOCTYPE html>
<html>
<head>
	<title>Game</title>
	 <meta name="viewport" content="width=device-width, initial-scale=1">

	<script type="text/javascript" src="js/jquery/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery-ui/jquery-ui.min.js"></script>
	<script type="text/javascript" src="js/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>
	<style type="text/css">
		.widget {
			width: 100px;
			height: 100px;
			overflow:hidden;
			position:absolute;
		}
		.widget img {
			position: absolute;
			width: 100px;
			height: 100px;
			/*top:100px;
			left:100px;
*/		}
	#canvas {
		width: 100%;
		height: 100%;
		overflow: hidden;
		position: absolute;
		border: 2px solid #000;
	} 

	</style>
</head>
<body>
	<div id="canvas" ></div>

	<script type="text/javascript">
		$(document).ready(function(){
			var div_no = 12; //randno(1,10);
			var dir = randno(1,5);
			for(var i=1;i<=div_no;i++)
			{
				
				var div = document.createElement("div");
				$(div).addClass("widget");
				$(div).css("top",randno(0,$(window).height()-100)+"px");
				$(div).css("left",randno(0,$(window).width()-100)+"px");
				//$(div).css("background-color","#"+randno(100,999)+randno(100,999)+randno(100,999));
				var img = document.createElement("img");
					$(img).attr("src","img/"+dir+"/"+i+".jpg");
					$(div).append(img);
					$("#canvas").append(div);	
			}
			

			$('.widget').draggable();
		});

		function randno(min,max)
		{
    		return Math.floor(Math.random()*(max-min+1)+min);
		}

	</script>

</body>
</html>